package ru.david.compmath4.math;

public class ParsingException extends RuntimeException {
    public ParsingException(String message) {
        super(message);
    }
}
