package ru.david.compmath4.gui.graph;

public class GridGap {
    public double width, height;

    public GridGap(double w, double h) {
        width = w;
        height = h;
    }
}
