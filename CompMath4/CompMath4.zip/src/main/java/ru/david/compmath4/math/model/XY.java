package ru.david.compmath4.math.model;

public class XY {
    public double x, y;

    public XY(double x, double y) {
        this.x = x;
        this.y = y;
    }
}
