package ru.david.compmath4.gui.input.listener;

public interface NumberInputListener {
    void onInput(double value);
}
