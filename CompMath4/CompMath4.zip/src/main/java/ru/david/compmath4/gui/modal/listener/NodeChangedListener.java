package ru.david.compmath4.gui.modal.listener;

import ru.david.compmath4.math.model.XY;

public interface NodeChangedListener {
    void closed(XY result);
}
