package ru.david.compmath4.math.expression;

public interface Expression {
    Double value();
}
