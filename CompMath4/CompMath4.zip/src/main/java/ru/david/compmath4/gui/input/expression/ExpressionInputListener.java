package ru.david.compmath4.gui.input.expression;

public interface ExpressionInputListener {
    void onRawExpressionInput(String raw);
}
